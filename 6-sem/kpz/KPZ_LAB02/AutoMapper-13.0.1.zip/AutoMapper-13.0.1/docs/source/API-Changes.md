# API Changes

Starting with version 9.0, you can find out [what changed](https://raw.githubusercontent.com/AutoMapper/AutoMapper/master/src/AutoMapper/ApiCompatBaseline.txt) in the public API from the last major version release.
From the [releases page](https://github.com/AutoMapper/AutoMapper/releases) you can reach the source code for that release and the version of ApiCompatBaseline.txt in that tree will tell you what changed.
A major version release is compared with the previous major version release (so 9.0.0 with 8.0.0) and a minor version release with the current major version release (so 9.1.1 with 9.0.0).