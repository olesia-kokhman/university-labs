﻿namespace OmmitedDTOModel3;

public class EntityDTO11 : BaseEntity
{
    public EntityDTO11()
    {
        //this.Entities10 = new EntityDTO10();
        //this.Entities8 = new EntityDTO8();
    }
    public EntityDTO10 Entities10 { get; set; }
    public EntityDTO8 Entities8 { get; set; }
}
