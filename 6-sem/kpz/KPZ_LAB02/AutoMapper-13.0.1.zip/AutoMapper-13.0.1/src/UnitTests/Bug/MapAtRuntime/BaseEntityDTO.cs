﻿namespace OmmitedDTOModel3;

public class BaseEntity
{
    public Guid Id { get; set; }
}
