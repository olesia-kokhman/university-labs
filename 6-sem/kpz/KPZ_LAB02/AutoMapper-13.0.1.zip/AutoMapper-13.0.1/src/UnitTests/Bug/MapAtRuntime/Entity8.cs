﻿namespace OmmitedDatabaseModel3;

public class Entity8 : BaseEntity
{
    public Entity8()
    {
        //this.Entities20 = new Entity20();
        //this.Entities22 = new Entity22();
        //this.Entities3 = new Entity3();
        //this.Entities11 = new Entity11();
        //this.Entities17 = new Entity17();
    }

    public Entity20 Entities20 { get; set; }
    public Entity17 Entities17 { get; set; }
    public Entity22 Entities22 { get; set; }
    public Entity3 Entities3 { get; set; }
    public Entity11 Entities11 { get; set; }
}
