﻿namespace OmmitedDatabaseModel3;

public class Entity20 : BaseEntity
{
    public Entity20()
    {
        //this.Entities8 = new Entity8();
        //this.Entities26 = new Entity26();
        //this.Entities12 = new Entity12();
        //this.Entities17 = new Entity17();
        //this.Entities21 = new Entity21();
        //this.Entities16 = new Entity16();
    }

    public Guid Entity3Id { get; set; }
    public Entity3 Entity3 { get; set; }
    public Guid Entity22Id { get; set; }
    public Entity22 Entity22 { get; set; }
    public Entity8 Entities8 { get; set; }
    public Entity26 Entities26 { get; set; }
    public Entity12 Entities12 { get; set; }
    public Entity17 Entities17 { get; set; }
    public Entity21 Entities21 { get; set; }
    public Entity16 Entities16 { get; set; }
}
