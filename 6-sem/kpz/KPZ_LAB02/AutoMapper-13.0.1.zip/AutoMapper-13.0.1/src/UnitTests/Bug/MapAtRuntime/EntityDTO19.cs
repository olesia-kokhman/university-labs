﻿namespace OmmitedDTOModel3;

public class EntityDTO19 : BaseEntity
{
    public Guid Entity25Id { get; set; }
    public EntityDTO25 Entity25 { get; set; }
}
