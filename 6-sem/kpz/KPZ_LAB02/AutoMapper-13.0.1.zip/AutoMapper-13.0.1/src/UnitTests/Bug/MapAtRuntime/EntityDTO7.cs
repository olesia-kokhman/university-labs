﻿namespace OmmitedDTOModel3;

public class EntityDTO7 : BaseEntity
{
    public Guid Entity25Id { get; set; }
    public EntityDTO25 Entity25 { get; set; }
    public Guid? Entity14Id { get; set; }
    public EntityDTO14 Entity14 { get; set; }
}
