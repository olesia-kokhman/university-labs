﻿namespace OmmitedDTOModel3WithCollections;

public class EntityDTO13 : BaseEntity
{
    public Guid Entity17Id { get; set; }
    public EntityDTO17 Entity17 { get; set; }
    public Guid Entity8Id { get; set; }
    public EntityDTO8 Entity8 { get; set; }
}
