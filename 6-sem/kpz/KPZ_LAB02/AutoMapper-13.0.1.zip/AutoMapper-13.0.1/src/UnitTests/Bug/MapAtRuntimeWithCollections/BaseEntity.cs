﻿namespace OmmitedDatabaseModel3WithCollections;

public class BaseEntity
{
    public Guid Id { get; set; }
}
