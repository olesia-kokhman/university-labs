﻿namespace OmmitedDTOModel3WithCollections;

public class BaseEntity
{
    public Guid Id { get; set; }
}
