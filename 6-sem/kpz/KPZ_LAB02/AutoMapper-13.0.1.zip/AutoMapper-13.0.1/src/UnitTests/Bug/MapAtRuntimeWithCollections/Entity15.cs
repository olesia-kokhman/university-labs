﻿namespace OmmitedDatabaseModel3WithCollections;

public class Entity15 : BaseEntity
{
    public Guid Entity17Id { get; set; }
    public Entity17 Entity17 { get; set; }
}
