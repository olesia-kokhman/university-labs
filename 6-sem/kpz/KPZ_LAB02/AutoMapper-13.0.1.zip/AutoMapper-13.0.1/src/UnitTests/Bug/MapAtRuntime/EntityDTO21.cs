﻿namespace OmmitedDTOModel3;

public class EntityDTO21 : BaseEntity
{
    public Guid Entity20Id { get; set; }
    public EntityDTO20 Entity20 { get; set; }
}
