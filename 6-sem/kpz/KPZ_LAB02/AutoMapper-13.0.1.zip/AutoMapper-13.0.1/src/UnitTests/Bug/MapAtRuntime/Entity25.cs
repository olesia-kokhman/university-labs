﻿namespace OmmitedDatabaseModel3;

public class Entity25 : BaseEntity
{
    public Entity25()
    {
        this.Entities19 = new Entity19();
    }

    public Entity19 Entities19 { get; set; }
    public Guid? Entity8Id { get; set; }
    public Entity8 Entity8 { get; set; }
    public Guid? Entity17Id { get; set; }
    public Entity17 Entity17 { get; set; }
}
