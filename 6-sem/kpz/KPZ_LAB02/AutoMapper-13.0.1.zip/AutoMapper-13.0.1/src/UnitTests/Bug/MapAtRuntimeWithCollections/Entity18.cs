﻿namespace OmmitedDatabaseModel3WithCollections;

public class Entity18 : BaseEntity
{
    public Guid Entity17Id { get; set; }
    public Entity17 Entity17 { get; set; }
    public Guid Entity20Id { get; set; }
    public Entity20 Entity20 { get; set; }
}
