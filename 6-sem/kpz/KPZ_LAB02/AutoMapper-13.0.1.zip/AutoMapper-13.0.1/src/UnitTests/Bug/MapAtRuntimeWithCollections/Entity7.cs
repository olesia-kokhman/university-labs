﻿namespace OmmitedDatabaseModel3WithCollections;

public class Entity7 : BaseEntity
{
    public Guid Entity25Id { get; set; }
    public Entity25 Entity25 { get; set; }
    public Guid? Entity14Id { get; set; }
    public Entity14 Entity14 { get; set; }
}
