﻿namespace OmmitedDTOModel3;

public class EntityDTO26 : BaseEntity
{
    public EntityDTO26()
    {
        this.Entities20 = new EntityDTO20();
    }

    public EntityDTO20 Entities20 { get; set; }
}
