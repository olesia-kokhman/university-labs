﻿namespace OmmitedDTOModel3;

public class EntityDTO22 : BaseEntity
{
    public EntityDTO22()
    {
        //this.Entities20 = new EntityDTO20();
        //this.Entities24 = new EntityDTO24();
    }
    public EntityDTO20 Entities20 { get; set; }
    public EntityDTO24 Entities24 { get; set; }
}
