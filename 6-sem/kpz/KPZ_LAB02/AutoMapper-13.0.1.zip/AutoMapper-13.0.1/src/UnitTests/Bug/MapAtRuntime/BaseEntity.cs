﻿namespace OmmitedDatabaseModel3;

public class BaseEntity
{
    public Guid Id { get; set; }
}
