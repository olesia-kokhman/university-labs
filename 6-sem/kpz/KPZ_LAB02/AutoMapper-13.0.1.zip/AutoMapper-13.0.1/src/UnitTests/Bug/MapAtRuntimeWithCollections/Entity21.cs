﻿namespace OmmitedDatabaseModel3WithCollections;

public class Entity21 : BaseEntity
{
    public Guid Entity20Id { get; set; }
    public Entity20 Entity20 { get; set; }
}
