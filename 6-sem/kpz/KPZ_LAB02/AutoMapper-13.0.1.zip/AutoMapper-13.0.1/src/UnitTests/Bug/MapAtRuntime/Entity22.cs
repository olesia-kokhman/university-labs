﻿namespace OmmitedDatabaseModel3;

public class Entity22 : BaseEntity
{
    public Entity22()
    {
        this.Entities20 = new Entity20();
        this.Entities24 = new Entity24();
    }
    public Entity20 Entities20 { get; set; }
    public Entity24 Entities24 { get; set; }
}
