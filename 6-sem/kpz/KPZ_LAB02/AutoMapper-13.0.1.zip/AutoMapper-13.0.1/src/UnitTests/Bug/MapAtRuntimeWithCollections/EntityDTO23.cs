﻿namespace OmmitedDTOModel3WithCollections;

public class EntityDTO23 : BaseEntity
{
    public Guid Entity5Id { get; set; }
    public EntityDTO5 Entity5 { get; set; }
}
