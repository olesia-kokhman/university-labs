﻿namespace OmmitedDTOModel3;

public class EntityDTO18 : BaseEntity
{
    public Guid Entity17Id { get; set; }
    public EntityDTO17 Entity17 { get; set; }
    public Guid Entity20Id { get; set; }
    public EntityDTO20 Entity20 { get; set; }
}
