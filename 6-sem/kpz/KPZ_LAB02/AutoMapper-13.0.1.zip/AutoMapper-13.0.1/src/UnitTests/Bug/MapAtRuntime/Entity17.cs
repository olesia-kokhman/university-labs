﻿namespace OmmitedDatabaseModel3;

public class Entity17 :BaseEntity
{
    public Entity17()
    {
        //this.Entities20 = new Entity20();
        this.Entities8 = new Entity8();
        this.Entities5 = new Entity5();
        this.Entities18 = new Entity18();
    }

    public Entity20 Entities20 { get; set; }
    public Entity8 Entities8 { get; set; }
    public Entity5 Entities5 { get; set; }
    public Entity18 Entities18 { get; set; }
}
