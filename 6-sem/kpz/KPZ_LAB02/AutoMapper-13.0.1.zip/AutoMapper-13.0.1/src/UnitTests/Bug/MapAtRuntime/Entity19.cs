﻿namespace OmmitedDatabaseModel3;

public class Entity19 : BaseEntity
{
    public Guid Entity25Id { get; set; }
    public Entity25 Entity25 { get; set; }
}
