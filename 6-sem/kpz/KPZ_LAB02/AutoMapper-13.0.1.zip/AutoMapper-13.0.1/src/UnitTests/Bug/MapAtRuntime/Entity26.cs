﻿namespace OmmitedDatabaseModel3;

public class Entity26 : BaseEntity
{
    public Entity26()
    {
        //this.Entities20 = new Entity20();
    }

    public Entity20 Entities20 { get; set; }
}
