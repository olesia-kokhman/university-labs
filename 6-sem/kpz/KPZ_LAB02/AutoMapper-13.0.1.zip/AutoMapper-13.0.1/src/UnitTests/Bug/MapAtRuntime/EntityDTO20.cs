﻿namespace OmmitedDTOModel3;

public class EntityDTO20 : BaseEntity
{
    //TODO Remove comments
    public EntityDTO20()
    {
        //this.Entities8 = new EntityDTO8();
        //this.Entities26 = new EntityDTO26();
        //this.Entities12 = new EntityDTO12();
        //this.Entities17 = new EntityDTO17();
        //this.Entities21 = new EntityDTO21();
        //this.Entities16 = new EntityDTO16();
    }

    public Guid Entity3Id { get; set; }
    public EntityDTO3 Entity3 { get; set; }
    public Guid Entity22Id { get; set; }
    public EntityDTO22 Entity22 { get; set; }
    public EntityDTO8 Entities8 { get; set; }
    public EntityDTO26 Entities26 { get; set; }
    public EntityDTO12 Entities12 { get; set; }
    public EntityDTO17 Entities17 { get; set; }
    public EntityDTO21 Entities21 { get; set; }
    public EntityDTO16 Entities16 { get; set; }
}
