﻿using System.Resources;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en")]

namespace System.Runtime.CompilerServices;

static class IsExternalInit { }